<?php
// parameter koneksi database
$sql_details = array(
    'user' => 'root',
    'pass' => '',
    'db'   => 'db_pegawai',
    'host' => 'localhost'
);
$con = $sql_details;
?>